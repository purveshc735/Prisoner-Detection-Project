import cv2
import urllib.request
import numpy as np
import os
import face_recognition
import requests  # Add this to handle HTTP requests

path = r'C:\Users\Admin\Desktop\prisoner detection\images'
url = 'http://192.168.193.56/cam-hi.jpg'

# ESP32-CAM webserver URL
esp32_url = 'http://192.168.193.56/'  # Replace with your ESP32-CAM IP address

images = []
classNames = []
myList = os.listdir(path)
print(myList)
for cl in myList:
    curImg = cv2.imread(f'{path}/{cl}')
    images.append(curImg)
    classNames.append(os.path.splitext(cl)[0])
print(classNames)

def findEncodings(images):
    encodeList = []
    for img in images:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        encode = face_recognition.face_encodings(img)[0]
        encodeList.append(encode)
    return encodeList

encodeListKnown = findEncodings(images)
print('Encoding Complete')

while True:
    img_resp = urllib.request.urlopen(url)
    imgnp = np.array(bytearray(img_resp.read()), dtype=np.uint8)
    img = cv2.imdecode(imgnp, -1)
    imgS = cv2.resize(img, (0, 0), None, 0.25, 0.25)
    imgS = cv2.cvtColor(imgS, cv2.COLOR_BGR2RGB)

    facesCurFrame = face_recognition.face_locations(imgS)
    encodesCurFrame = face_recognition.face_encodings(imgS, facesCurFrame)

    for encodeFace, faceLoc in zip(encodesCurFrame, facesCurFrame):
        matches = face_recognition.compare_faces(encodeListKnown, encodeFace)
        faceDis = face_recognition.face_distance(encodeListKnown, encodeFace)
        matchIndex = np.argmin(faceDis)

        if matches[matchIndex]:
            name = classNames[matchIndex].upper()
            y1, x2, y2, x1 = faceLoc
            y1, x2, y2, x1 = y1 * 4, x2 * 4, y2 * 4, x1 * 4
            cv2.rectangle(img, (x1, y1), (x2, y2), (0, 255, 0), 2)
            cv2.rectangle(img, (x1, y2 - 35), (x2, y2), (0, 255, 0), cv2.FILLED)
            cv2.putText(img, name, (x1 + 6, y2 - 6), cv2.FONT_HERSHEY_COMPLEX, 1, (255, 255, 255), 2)

            # If recognized face matches, send "Unwanted face detected"
            print(f"Face recognized: {name}")
            try:
                response = requests.get(esp32_url, params={'alert': 'Unwanted face detected'})
                print(f"ESP32 Response: {response.text}")
            except Exception as e:
                print(f"Failed to send request to ESP32: {e}")

        else:
            # If face does not match, send "No" (Unknown face)
            #print("Face not recognized")
            try:
                response = requests.get(esp32_url, params={'alert': 'Normal face detected'})
                print(f"ESP32 Response: {response.text}")
            except Exception as e:
                print(f"Failed to send request to ESP32: {e}")

    cv2.imshow('Webcam', img)
    key = cv2.waitKey(5)
    if key == ord('q'):
        break

cv2.destroyAllWindows()
