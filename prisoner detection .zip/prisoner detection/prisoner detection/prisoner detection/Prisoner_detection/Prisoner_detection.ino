#include <WiFi.h>
#include <esp32cam.h>
#include <WebServer.h>

// Replace with your network credentials
const char* WIFI_SSID = "AA1";
const char* WIFI_PASS = "1234567890";

// Define pins for LEDs and buzzer
#define RED_LED_PIN 12
#define GREEN_LED_PIN 13
#define BUZZER_PIN 14
#define ALARAM_OFF_PIN 15

// Create a WebServer object on port 80
WebServer server(80);

static auto loRes = esp32cam::Resolution::find(320, 240);
static auto midRes = esp32cam::Resolution::find(350, 530);
static auto hiRes = esp32cam::Resolution::find(800, 600);

// Function to serve JPG image from camera
void serveJpg() {
  auto frame = esp32cam::capture();
  if (frame == nullptr) {
    Serial.println("CAPTURE FAIL");
    server.send(503, "image/jpeg", "");
    return;
  }
  //Serial.printf("CAPTURE OK %dx%d %db\n", frame->getWidth(), frame->getHeight(), static_cast<int>(frame->size()));
  server.sendHeader("Content-Length", String(frame->size()));
  server.send(200, "image/jpeg");
  WiFiClient client = server.client();
  frame->writeTo(client);
}

void handleJpgLo() {
  if (!esp32cam::Camera.changeResolution(loRes)) {
    Serial.println("SET-LO-RES FAIL");
  }
  serveJpg();
}

void handleJpgHi() {
  if (!esp32cam::Camera.changeResolution(hiRes)) {
    Serial.println("SET-HI-RES FAIL");
  }
  serveJpg();
}

void handleJpgMid() {
  if (!esp32cam::Camera.changeResolution(midRes)) {
    Serial.println("SET-MID-RES FAIL");
  }
  serveJpg();
}

// Function to control LED and buzzer based on incoming alert
void controlDevice(const String& alert) {
  if (alert == "Unwanted face detected") {
    // Turn on Red LED and Buzzer
    digitalWrite(RED_LED_PIN, HIGH);
    digitalWrite(GREEN_LED_PIN, LOW);
    digitalWrite(BUZZER_PIN, HIGH);
    Serial.println("Unwanted face detected! Red LED and Buzzer ON, Green LED OFF");
  } else if (alert == "Normal face detected") {
    // Turn on Green LED, turn off Red LED and Buzzer
    digitalWrite(RED_LED_PIN, LOW);
    digitalWrite(GREEN_LED_PIN, HIGH);
    digitalWrite(BUZZER_PIN, LOW);
    Serial.println("No match! Green LED ON, Red LED and Buzzer OFF");
  } 
}

void setup() {
  // Start serial monitor
  Serial.begin(115200);

  Serial.println();
  {
    using namespace esp32cam;
    Config cfg;
    cfg.setPins(pins::AiThinker);  // Configure the pins for the AI Thinker board
    cfg.setResolution(hiRes);  // Set high resolution as default
    cfg.setBufferCount(2);
    cfg.setJpeg(80);  // Set JPEG compression quality
    bool ok = Camera.begin(cfg);
    Serial.println(ok ? "CAMERA OK" : "CAMERA FAIL");
  }

  // Connect to Wi-Fi
  WiFi.persistent(false);
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.println("Connecting to WiFi...");
  }
  Serial.println("Connected to WiFi");
  Serial.print("http://");
  Serial.println(WiFi.localIP());

  // Initialize LED and Buzzer pins as output
  pinMode(RED_LED_PIN, OUTPUT);
  pinMode(GREEN_LED_PIN, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(ALARAM_OFF_PIN, INPUT);

  // Turn everything off initially
  digitalWrite(RED_LED_PIN, LOW);
  digitalWrite(GREEN_LED_PIN, HIGH);
  digitalWrite(BUZZER_PIN, LOW);

  // Set up web server to handle image requests
  server.on("/cam-lo.jpg", handleJpgLo);  // Low resolution
  server.on("/cam-hi.jpg", handleJpgHi);  // High resolution
  server.on("/cam-mid.jpg", handleJpgMid);  // Medium resolution

  // Set up web server to handle alerts
  server.on("/", HTTP_GET, []() {
    if (server.hasArg("alert")) {
      String alert = server.arg("alert");
      controlDevice(alert);  // Control LEDs and Buzzer
      server.send(200, "text/plain", "Alert received: " + alert);
    } else {
      server.send(400, "text/plain", "Alert parameter missing");
    }
  });

  // Start the server
  server.begin();
}

void loop() {
  // Handle incoming HTTP requests
  server.handleClient();
  int Read = digitalRead(ALARAM_OFF_PIN);

  if(Read == HIGH)
  {
    digitalWrite(RED_LED_PIN, LOW);
    digitalWrite(GREEN_LED_PIN, HIGH);
    digitalWrite(BUZZER_PIN, LOW);
  }

}
